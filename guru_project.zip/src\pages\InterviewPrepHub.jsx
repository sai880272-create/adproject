import React, { useState } from 'react';
import { BookOpen, Mic, Code, Star, ArrowLeft, Download, Bot, Play, CheckCircle, FileText } from 'lucide-react';

const InterviewPrepHub = () => {
  const [view, setView] = useState('hub');

  const renderHub = () => (
    <div className="page-content animate-fade-in">
      <div className="card">
        <h3><BookOpen size={20} style={{ marginRight: '10px' }} /> Preparation Resources</h3>
        <p style={{ color: 'var(--text-muted)', marginTop: '10px', lineHeight: '1.6' }}>
          Sharpen your skills and get ready for your next big interview.
        </p>
      </div>

      <div className="stats-grid">
        <div className="stat-card" style={{ textAlign: 'left', padding: '25px' }}>
          <h4 style={{ color: '#fff' }}><FileText size={20} style={{ marginRight: '10px', color: 'var(--gold-primary)' }} /> Resume Building</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Get tips and templates for creating a standout resume.</p>
          <button className="btn" onClick={() => setView('guides')}>View Guides</button>
        </div>
        <div className="stat-card" style={{ textAlign: 'left', padding: '25px' }}>
          <h4 style={{ color: '#fff' }}><Mic size={20} style={{ marginRight: '10px', color: 'var(--gold-primary)' }} /> Mock Interviews</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Practice with AI-powered mock interviews and get instant feedback.</p>
          <button className="btn btn-filled" onClick={() => setView('mock')}>Start Practice</button>
        </div>
        <div className="stat-card" style={{ textAlign: 'left', padding: '25px' }}>
          <h4 style={{ color: '#fff' }}><Code size={20} style={{ marginRight: '10px', color: 'var(--gold-primary)' }} /> Coding Challenges</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Solve challenges from real companies to test your abilities.</p>
          <button className="btn" onClick={() => setView('coding')}>Go to Challenges</button>
        </div>
      </div>

      <div className="card">
        <h3><Star size={20} style={{ marginRight: '10px' }} /> Interview Tips & Tricks</h3>
        <ul style={{ color: 'var(--text-muted)', marginTop: '15px', paddingLeft: '20px', lineHeight: '1.8' }}>
          <li><strong>Research the Company:</strong> Understand their mission, products, and recent news.</li>
          <li><strong>Prepare Your Questions:</strong> Have thoughtful questions ready to ask the interviewer. It shows you're engaged.</li>
          <li><strong>Dress Professionally:</strong> First impressions matter, even for video calls.</li>
          <li><strong>Follow Up:</strong> Send a thank-you email within 24 hours of your interview.</li>
        </ul>
      </div>
    </div>
  );

  const renderGuides = () => (
    <div className="page-content animate-fade-in">
      <button className="btn" style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }} onClick={() => setView('hub')}>
        <ArrowLeft size={16} /> Back to Hub
      </button>
      <div className="card">
        <h3><Star size={20} style={{ marginRight: '10px' }} /> Top Tips for a Winning Resume</h3>
      </div>
      <div className="stats-grid">
        <div className="stat-card" style={{ textAlign: 'left' }}>
          <h4 style={{ color: '#fff' }}>Use Action Verbs</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Start bullet points with powerful verbs like "Orchestrated", "Engineered", "Accelerated".</p>
        </div>
        <div className="stat-card" style={{ textAlign: 'left' }}>
          <h4 style={{ color: '#fff' }}>Quantify Achievements</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Instead of "Improved performance", write "Improved server response time by 15%".</p>
        </div>
        <div className="stat-card" style={{ textAlign: 'left' }}>
          <h4 style={{ color: '#fff' }}>Tailor to the Job</h4>
          <p style={{ margin: '10px 0', color: 'var(--text-muted)' }}>Highlight skills and experiences mentioned in the job description.</p>
        </div>
      </div>
      <div className="card">
        <button className="btn btn-filled" onClick={() => alert('Downloading Templates...')}>
          <Download size={18} style={{ marginRight: '8px' }} /> Download Template Pack
        </button>
      </div>
    </div>
  );

  const renderMock = () => (
    <div className="page-content animate-fade-in">
      <button className="btn" style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }} onClick={() => setView('hub')}>
        <ArrowLeft size={16} /> Back to Hub
      </button>
      <div className="card">
        <h3><Mic size={20} style={{ marginRight: '10px' }} /> Practice Your Interview Skills</h3>
        <p style={{ color: 'var(--text-muted)', marginTop: '10px', lineHeight: '1.6' }}>
          Our AI will ask you common questions and provide feedback on your answers, pacing, and use of filler words.
        </p>
      </div>
      <div className="card" style={{ textAlign: 'center', padding: '60px' }}>
        <Bot size={64} style={{ color: 'var(--text-muted)', marginBottom: '20px' }} />
        <h4 style={{ color: '#fff' }}>Ready to Start?</h4>
        <p style={{ color: 'var(--text-muted)', margin: '10px 0 30px' }}>Choose an interview type to begin.</p>
        <div className="flex gap-20" style={{ justifyContent: 'center' }}>
          <button className="btn btn-filled" style={{ padding: '15px 30px' }} onClick={() => alert('Starting Behavioral Interview...')}>Behavioral Interview</button>
          <button className="btn" style={{ padding: '15px 30px' }} onClick={() => alert('Starting Technical Interview...')}>Technical Interview</button>
        </div>
      </div>
    </div>
  );

  const renderCoding = () => (
    <div className="page-content animate-fade-in">
      <button className="btn" style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }} onClick={() => setView('hub')}>
        <ArrowLeft size={16} /> Back to Hub
      </button>
      <div className="card">
        <h3><Code size={20} style={{ marginRight: '10px' }} /> Test Your Problem-Solving Skills</h3>
      </div>
      <div className="card">
        <table className="lux-table">
          <thead>
            <tr>
              <th>Challenge</th>
              <th>Difficulty</th>
              <th>Success Rate</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {[
              { name: 'Two Sum', diff: 'Easy', rate: '48.5%' },
              { name: 'Reverse a Linked List', diff: 'Easy', rate: '72.1%' },
              { name: 'Validate Binary Search Tree', diff: 'Medium', rate: '35.9%' }
            ].map(c => (
              <tr key={c.name}>
                <td>{c.name}</td>
                <td><span className={`badge ${c.diff === 'Easy' ? 'badge-success' : 'badge-pending'}`}>{c.diff}</span></td>
                <td>{c.rate}</td>
                <td><button className="btn btn-filled" style={{ padding: '5px 10px', fontSize: '0.7rem' }}>Start</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  switch(view) {
    case 'guides': return renderGuides();
    case 'mock': return renderMock();
    case 'coding': return renderCoding();
    default: return renderHub();
  }
};


export default InterviewPrepHub;
