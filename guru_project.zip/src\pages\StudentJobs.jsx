import React from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, DollarSign, Clock, Calendar } from 'lucide-react';

const StudentJobs = () => {
  const { jobs, applyToJob } = useApp();

  const handleApply = (job) => {
    applyToJob(job.id);
    alert(`Success! Your application for "${job.title}" has been submitted.`);
  };

  return (
    <div className="page-content animate-fade-in">
      <div className="card">
        <h3>Available Opportunities</h3>
        <p style={{ color: 'var(--text-muted)', margin: '10px 0 20px' }}>
          Explore elite positions curated specially for your profile.
        </p>

        <div className="jobs-container" style={{ display: 'grid', gap: '20px' }}>
          {jobs.map(job => (
            <div key={job.id} className="card job-card-detailed" style={{ marginBottom: 0, padding: '20px' }}>
              <div className="flex justify-between items-start">
                <div>
                  <h3 style={{ color: '#fff', fontSize: '1.2rem' }}>{job.title}</h3>
                  <p style={{ color: 'var(--gold-primary)', margin: '5px 0' }}>{job.company}</p>
                  
                  <div className="flex gap-20" style={{ marginTop: '15px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    <span className="flex items-center gap-10"><DollarSign size={14} /> {job.salary}</span>
                    <span className="flex items-center gap-10"><Clock size={14} /> {job.type}</span>
                    <span className="flex items-center gap-10"><Calendar size={14} /> Posted {job.posted}</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-10">
                  <button className="btn btn-filled" onClick={() => handleApply(job)}>Apply Now</button>
                  <button className="btn">View Details</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentJobs;
