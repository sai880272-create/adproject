import React from 'react';
import { useApp } from '../context/AppContext';
import { Users } from 'lucide-react';

const CompanyApplicants = () => {
  const { applications, jobs, updateApplicationStatus, addNotification } = useApp();
  
  // Simulations: only show apps for TechNova jobs
  const companyApps = applications.filter(app => jobs.find(j => j.id === app.jobId)?.company === "TechNova");

  const handleAction = (id, status, name) => {
    updateApplicationStatus(id, status);
    addNotification({
      type: status === 'Accepted' ? 'success' : 'error',
      text: `Candidate ${name} has been ${status.toLowerCase()}.`
    });
  };

  return (
    <div className="page-content animate-fade-in">
      <div className="card">
        <h3><Users size={20} style={{ marginRight: '10px', verticalAlign: 'middle' }} /> Recent Applicants</h3>
        <p style={{ color: 'var(--text-muted)', marginTop: '10px', lineHeight: '1.6' }}>
          Review and manage applicants for your active positions.
        </p>
      </div>

      <div className="card">
        <table className="lux-table">
          <thead>
            <tr>
              <th>Candidate</th>
              <th>Position</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {companyApps.length > 0 ? companyApps.map(app => {
              const job = jobs.find(j => j.id === app.jobId) || { title: 'Unknown' };
              return (
                <tr key={app.id}>
                  <td>
                    <a href="#" onClick={(e) => { e.preventDefault(); alert('View Profile Simulation'); }} style={{ color: 'var(--gold-light)', textDecoration: 'underline' }}>
                      {app.studentName}
                    </a>
                  </td>
                  <td>{job.title}</td>
                  <td>
                    <span className={`badge ${app.status === 'Accepted' ? 'badge-accepted' : (app.status === 'Rejected' ? 'badge-rejected' : 'badge-pending')}`}>
                      {app.status}
                    </span>
                  </td>
                  <td>
                    <button 
                      className="btn" 
                      style={{ padding: '5px 10px', fontSize: '0.7rem', marginRight: '5px' }} 
                      onClick={() => alert('View Profile Simulation')}
                    >
                      View Profile
                    </button>
                    <button 
                      className="btn btn-filled" 
                      style={{ padding: '5px 10px', fontSize: '0.7rem', marginRight: '5px' }} 
                      onClick={() => handleAction(app.id, 'Accepted', app.studentName)}
                    >
                      Accept
                    </button>
                    <button 
                      className="btn btn-danger" 
                      style={{ padding: '5px 10px', fontSize: '0.7rem' }} 
                      onClick={() => handleAction(app.id, 'Rejected', app.studentName)}
                    >
                      Reject
                    </button>
                  </td>
                </tr>
              );
            }) : (
              <tr><td colSpan="4" style={{ textAlign: 'center' }}>No applicants found for your jobs.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CompanyApplicants;
