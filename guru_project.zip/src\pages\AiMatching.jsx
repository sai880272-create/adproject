import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Loader2 } from 'lucide-react';

const AiMatching = () => {
  const [loading, setLoading] = useState(false);
  const [matches, setMatches] = useState([]);
  const { jobs } = useApp();

  const runAnalysis = () => {
    setLoading(true);
    setMatches([]);
    setTimeout(() => {
      setMatches(jobs.slice(0, 2));
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="page-content animate-fade-in">
      <div className="card">
        <div className="flex items-center gap-10">
          <Sparkles color="var(--gold-primary)" />
          <h3>AI Job Matching</h3>
        </div>
        <p style={{ color: 'var(--text-muted)', margin: '10px 0 20px' }}>
          Our AI analyzes your skills, interests, and academic performance to find your perfect career match.
        </p>

        <button 
          className="btn btn-filled" 
          onClick={runAnalysis}
          disabled={loading}
          style={{ display: 'flex', alignItems: 'center', gap: '10px' }}
        >
          {loading ? <Loader2 className="animate-spin" size={18} /> : <Sparkles size={18} />}
          {loading ? 'Analyzing Profile...' : 'Find My Matches'}
        </button>
      </div>

      {matches.length > 0 && (
        <div className="animate-fade-in" style={{ marginTop: '20px' }}>
          <h4>Your Top Matches</h4>
          <div style={{ display: 'grid', gap: '15px', marginTop: '15px' }}>
            {matches.map(job => (
              <div key={job.id} className="card" style={{ background: 'var(--bg-panel-lighter)', borderLeft: '4px solid var(--success)' }}>
                <div className="flex justify-between items-center">
                  <div>
                    <h5 style={{ color: '#fff', fontSize: '1.1rem' }}>{job.title}</h5>
                    <p style={{ color: 'var(--gold-primary)' }}>{job.company}</p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '5px' }}>
                      Match Score: <span style={{ color: '#4caf50', fontWeight: 'bold' }}>98%</span>
                    </p>
                  </div>
                  <button className="btn btn-filled">Apply Now</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AiMatching;
