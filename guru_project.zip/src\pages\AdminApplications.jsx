import React from 'react';
import { useApp } from '../context/AppContext';
import { Check, X, FileText } from 'lucide-react';

const AdminApplications = () => {
  const { applications, jobs, addNotification } = useApp();

  const updateAppStatus = (appId, status) => {
    // In a real app, this would be an API call and update context state
    addNotification({
      type: status === 'Accepted' ? 'success' : 'error',
      text: `Application has been ${status.toLowerCase()}`
    });
    alert(`Application ID: ${appId} marked as ${status}`);
  };

  return (
    <div className="page-content animate-fade-in">
      <div className="card">
        <h3><FileText size={20} style={{ marginRight: '10px', verticalAlign: 'middle' }} /> All Student Applications</h3>
        <p style={{ color: 'var(--text-muted)', marginTop: '10px', lineHeight: '1.6' }}>
          Review and manage all student job applications across the platform.
        </p>
      </div>

      <div className="card">
        <table className="lux-table">
          <thead>
            <tr>
              <th>Student</th>
              <th>Job Applied</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {applications.length > 0 ? applications.map(app => {
              const job = jobs.find(j => j.id === app.jobId) || { title: 'Unknown' };
              return (
                <tr key={app.id}>
                  <td>{app.studentName}</td>
                  <td>{job.title}</td>
                  <td>
                    <span className={`badge ${app.status === 'Accepted' ? 'badge-accepted' : (app.status === 'Rejected' ? 'badge-rejected' : 'badge-pending')}`}>
                      {app.status}
                    </span>
                  </td>
                  <td>
                    <button 
                      className="btn btn-filled" 
                      style={{ padding: '5px 10px', fontSize: '0.7rem', marginRight: '5px' }} 
                      onClick={() => updateAppStatus(app.id, 'Accepted')}
                    >
                      <Check size={14} />
                    </button>
                    <button 
                      className="btn btn-danger" 
                      style={{ padding: '5px 10px', fontSize: '0.7rem' }} 
                      onClick={() => updateAppStatus(app.id, 'Rejected')}
                    >
                      <X size={14} />
                    </button>
                  </td>
                </tr>
              );
            }) : (
              <tr><td colSpan="4" style={{ textAlign: 'center' }}>No applications found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminApplications;
